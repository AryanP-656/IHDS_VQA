Paper ID: 2495  
Title: Visual Question Answering on the Indian Heritage in Digital Space Dataset Using the BLIP Model  
Authors: Aryan S Phadnis, Vibhu V Revadi, Abhishek BR, Vinayak Neginhal, Dr Uday Kulkarni, Shashank Hegde  
Affiliation: School of Computer Science and Engineering, KLE Technological University, Hubballi, India  

COMPILATION INSTRUCTIONS:  
1. Required LaTeX files:  
   - apalike.bst  
   - apalike.sty  
   - article.cls  
   - main.tex  
   - mybib.bib  
   - scitepress.sty  
   - scitepress.eps  
   - orcid.eps
   - Image files:  
     * image.png  
     * image_1.png  
     * image_2.png  
     * image_3.jpg  
     * image_4.png  
     * plot.png
     * prop.png  

2. Compile using Overleaf.  
3. Compilation steps:  
   a. Run PDFLaTeX on `main.tex`.  
   b. Run BibTeX for references.  
   c. Re-run PDFLaTeX twice to resolve cross-references.  

NOTE: All dependencies are included in this zip folder. Ensure all files are in the same directory.  